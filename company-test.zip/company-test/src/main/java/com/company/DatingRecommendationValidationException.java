package com.company;

public class DatingRecommendationValidationException extends Exception {
public DatingRecommendationValidationException(String errorMessage){
    super(errorMessage);
}
}

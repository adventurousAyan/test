package com.company;

public class TDDConstants {

    public static final String NO_MATCHES = "No match as user list is empty";
    public static final String INPUT_USER_EMPTY = "Input User is empty";
    public static final String LIMIT_INVALID = "Limit is invalid";

}

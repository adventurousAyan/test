package com.company;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class DatingRecommendationTest {

  @Test
  public void testUserMatchesTop2() throws DatingRecommendationValidationException {
    DatingRecommendationService ds = new DatingRecommendationService();
    List<User> users = new ArrayList<>();
    User user1 = new User();
    user1.setName("UserA");
    user1.setAge(25);
    user1.setGender("Female");
    user1.setInterests(Arrays.asList(new String[]{"Cricket"}));
    users.add(user1);
    User user2 = new User();
    user2.setName("UserB");
    user2.setAge(27);
    user2.setGender("Male");
    user2.setInterests(Arrays.asList(new String[]{"Cricket", "Football", "Movies"}));
    users.add(user2);
    User user3 = new User();
    user3.setName("UserC");
    user3.setAge(26);
    user3.setGender("Male");
    user3.setInterests(Arrays.asList(new String[]{"Movies", "Tennis", "Football", "Cricket"}));
    users.add(user3);
    User user4 = new User();
    user4.setName("UserD");
    user4.setAge(24);
    user4.setGender("Female");
    user4.setInterests(Arrays.asList(new String[]{"Tennis", "Football", "Badminton"}));
    users.add(user4);
    User user5 = new User();
    user5.setName("UserE");
    user5.setAge(32);
    user5.setGender("Female");
    user5.setInterests(Arrays.asList(new String[]{"Cricket", "Football", "Movies", "Badminton"}));
    users.add(user5);
    List<User> returnedUsers = ds.getMatches(user2, users, 2);
    assertEquals(returnedUsers.size(), 2);
    assertEquals(returnedUsers.get(0).getName(), "UserA");

  }

  @Test
  public void testUserMatchesNoMatch() throws DatingRecommendationValidationException {
    DatingRecommendationService ds = new DatingRecommendationService();
    List<User> users = new ArrayList<>();
    User user1 = new User();
    user1.setName("UserA");
    user1.setAge(25);
    user1.setGender("Female");
    user1.setInterests(Arrays.asList(new String[]{"Cricket"}));
    DatingRecommendationValidationException exception = assertThrows(DatingRecommendationValidationException.class,
            () -> ds.getMatches(user1, null, 2));
    if (exception != null) {
      System.out.println(exception.getMessage());
      assertEquals(exception.getMessage(), TDDConstants.NO_MATCHES);
    }
  }

  @Test
  public void testUserMatchesUserInputNull() throws DatingRecommendationValidationException {
    DatingRecommendationService ds = new DatingRecommendationService();
    List<User> users = new ArrayList<>();
    User user1 = new User();
    user1.setName("UserA");
    user1.setAge(25);
    user1.setGender("Female");
    user1.setInterests(Arrays.asList(new String[]{"Cricket"}));
    users.add(user1);
    DatingRecommendationValidationException exception = assertThrows(DatingRecommendationValidationException.class,
            () -> ds.getMatches(null, users, 2));
    if (exception != null) {
      System.out.println(exception.getMessage());
      assertEquals(exception.getMessage(), TDDConstants.INPUT_USER_EMPTY);
    }
  }

  @Test
  public void testUserMatchesLimitInvalid() throws DatingRecommendationValidationException {
    DatingRecommendationService ds = new DatingRecommendationService();
    List<User> users = new ArrayList<>();
    User user1 = new User();
    user1.setName("UserA");
    user1.setAge(25);
    user1.setGender("Female");
    user1.setInterests(Arrays.asList(new String[]{"Cricket"}));
    users.add(user1);
    DatingRecommendationValidationException exception = assertThrows(DatingRecommendationValidationException.class,
            () -> ds.getMatches(user1, users, 5));
    if (exception != null) {
      System.out.println(exception.getMessage());
      assertEquals(exception.getMessage(), TDDConstants.LIMIT_INVALID);
    }
  }
  @Test
  public void testUserMatchesUserListEmpty() throws DatingRecommendationValidationException {
    DatingRecommendationService ds = new DatingRecommendationService();
    List<User> users = new ArrayList<>();
    User user1 = new User();
    user1.setName("UserA");
    user1.setAge(25);
    user1.setGender("Female");
    user1.setInterests(Arrays.asList(new String[]{"Cricket"}));
    DatingRecommendationValidationException exception = assertThrows(DatingRecommendationValidationException.class,
            () -> ds.getMatches(null, users, 1));
    if (exception != null) {
      System.out.println(exception.getMessage());
      assertEquals(exception.getMessage(), TDDConstants.NO_MATCHES);
    }
  }
}